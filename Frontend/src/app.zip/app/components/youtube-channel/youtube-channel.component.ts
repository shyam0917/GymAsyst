import { Component, OnInit } from '@angular/core';
import { YoutubeService } from '../../services/youtube.service';

@Component({
  selector: 'app-youtube-channel',
  templateUrl: './youtube-channel.component.html',
  styleUrls: ['./youtube-channel.component.css']
})

export class YoutubeChannelComponent implements OnInit {
  videos: any[];

  constructor(private youTubeService: YoutubeService) { }

  ngOnInit() {
  this.getVideos();
  }

  getVideos(){
    this.youTubeService.getVideosForChanel('UC_LtA_EtCr7Jp5ofOsYt18g', 15)
    .subscribe(res => {
console.log(JSON.stringify(res));
    },err=>{
console.log(err);
    });
  }

}
