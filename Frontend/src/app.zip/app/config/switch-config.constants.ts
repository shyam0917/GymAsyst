export class SwitchConfig {
  public static  APPS = ['smartpathshala', 'codestrippers','localhost'] ;
  public static  APP = SwitchConfig.APPS[2] ;
}
